$(document).ready(function() {
    setTimeout(function() {
        window.location.href = "/analysis/"; // 3초 후에 analysis.html 페이지로 이동
    }, 3000);
});